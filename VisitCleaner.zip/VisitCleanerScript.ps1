# VisitCleanerScript.ps1

# Function to check if the script is running as an administrator
function Test-IsAdmin {
    $currentUser = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    return $currentUser.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# If not running as admin, relaunch as admin
if (-not (Test-IsAdmin)) {
    Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}

# Initialize total space freed
$global:totalSpaceFreed = 0

# Function to log messages and track space freed
function Log-Message {
    param (
        [string]$message,
        [int64]$spaceFreed = 0
    )
    $global:totalSpaceFreed += $spaceFreed
    $message | Out-File -FilePath "C:\Users\Paul\desktop\VisitCleaner.log" -Append
    Write-Host $message
    if ($spaceFreed -gt 0) {
        $spaceFreedInMB = [math]::Round($spaceFreed / 1MB, 2)
        $spaceMessage = "Freed space: $spaceFreedInMB MB"
        $spaceMessage | Out-File -FilePath "C:\Users\Paul\desktop\VisitCleaner.log" -Append
        Write-Host $spaceMessage
    }
}

# Function to log start and end time
function Log-ExecutionTime {
    param (
        [string]$taskName,
        [datetime]$startTime
    )
    $endTime = Get-Date
    $duration = $endTime - $startTime
    $durationMessage = "$taskName took $($duration.TotalSeconds) seconds."
    Log-Message $durationMessage
}

# Function to optimize SSD
function Optimize-SSD {
    $startTime = Get-Date
    Log-Message "Optimizing SSD..."
    try {
        Optimize-Volume -DriveLetter C -ReTrim -Verbose
    } catch {
        Log-Message "Failed to optimize SSD: $_"
    }
    Log-ExecutionTime "Optimize-SSD" $startTime
}

# Function to clean temporary files
function Clean-TempFiles {
    $startTime = Get-Date
    Log-Message "Cleaning temporary files..."
    $before = (Get-PSDrive C).Free
    Get-ChildItem -Path $env:TEMP -Recurse -ErrorAction SilentlyContinue | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue
    $after = (Get-PSDrive C).Free
    Log-Message "Temporary files cleaned." ($after - $before)
    Log-ExecutionTime "Clean-TempFiles" $startTime
}

# Function to clear browser cache
function Clean-BrowserCache {
    $startTime = Get-Date
    Log-Message "Cleaning browser cache..."
    $before = (Get-PSDrive C).Free
    # Clear Chrome Cache
    Remove-Item -Path "$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Cache\*" -Force -Recurse -ErrorAction SilentlyContinue
    # Clear Firefox Cache
    Remove-Item -Path "$env:LOCALAPPDATA\Mozilla\Firefox\Profiles\*\cache2\*" -Force -Recurse -ErrorAction SilentlyContinue
    $after = (Get-PSDrive C).Free
    Log-Message "Browser cache cleaned." ($after - $before)
    Log-ExecutionTime "Clean-BrowserCache" $startTime
}

# Function to clean thumbnail cache
function Clean-ThumbnailCache {
    $startTime = Get-Date
    Log-Message "Cleaning thumbnail cache..."
    $before = (Get-PSDrive C).Free
    Remove-Item -Path "$env:LOCALAPPDATA\Microsoft\Windows\Explorer\thumbcache_*.db" -Force -ErrorAction SilentlyContinue
    $after = (Get-PSDrive C).Free
    Log-Message "Thumbnail cache cleaned." ($after - $before)
    Log-ExecutionTime "Clean-ThumbnailCache" $startTime
}

# Function to clean prefetch folder
function Clean-Prefetch {
    $startTime = Get-Date
    Log-Message "Cleaning prefetch folder..."
    $before = (Get-PSDrive C).Free
    Remove-Item -Path "$env:SystemRoot\Prefetch\*" -Force -ErrorAction SilentlyContinue
    $after = (Get-PSDrive C).Free
    Log-Message "Prefetch folder cleaned." ($after - $before)
    Log-ExecutionTime "Clean-Prefetch" $startTime
}

# Function to analyze disk space
function Disk-SpaceAnalysis {
    $startTime = Get-Date
    Log-Message "Analyzing disk space..."
    $diskSpace = Get-PSDrive C | Select-Object Used, Free, @{Name="Used (%)";Expression={($_.Used/($_.Used+$_.Free))*100}}
    Log-Message "Disk space analysis: Used: $($diskSpace.Used), Free: $($diskSpace.Free), Used (%): $($diskSpace."Used (%)")"
    Log-ExecutionTime "Disk-SpaceAnalysis" $startTime
}

# Function to clean temporary fonts
function Clean-TempFonts {
    $startTime = Get-Date
    Log-Message "Cleaning temporary fonts..."
    $before = (Get-PSDrive C).Free
    Remove-Item -Path "$env:SystemRoot\Fonts\~*" -Force -ErrorAction SilentlyContinue
    $after = (Get-PSDrive C).Free
    Log-Message "Temporary fonts cleaned." ($after - $before)
    Log-ExecutionTime "Clean-TempFonts" $startTime
}

# Function to flush DNS cache
function Flush-DNSCache {
    $startTime = Get-Date
    Log-Message "Flushing DNS cache..."
    ipconfig /flushdns | Out-String | Log-Message
    Log-ExecutionTime "Flush-DNSCache" $startTime
}

# Function to clean system temporary files
function Clean-SystemTempFiles {
    $startTime = Get-Date
    Log-Message "Cleaning system temporary files..."
    $before = (Get-PSDrive C).Free
    Remove-Item -Path "$env:SystemRoot\Temp\*" -Force -Recurse -ErrorAction SilentlyContinue
    $after = (Get-PSDrive C).Free
    Log-Message "System temporary files cleaned." ($after - $before)
    Log-ExecutionTime "Clean-SystemTempFiles" $startTime
}

# Function to clean printer temporary files
function Clean-PrinterTempFiles {
    $startTime = Get-Date
    Log-Message "Cleaning printer temporary files..."
    $before = (Get-PSDrive C).Free
    Remove-Item -Path "$env:SystemRoot\System32\spool\PRINTERS\*" -Force -ErrorAction SilentlyContinue
    $after = (Get-PSDrive C).Free
    Log-Message "Printer temporary files cleaned." ($after - $before)
    Log-ExecutionTime "Clean-PrinterTempFiles" $startTime
}

# Function to clean DirectX Shader Cache
function Clean-DXShaderCache {
    $startTime = Get-Date
    Log-Message "Cleaning DirectX Shader Cache..."
    $before = (Get-PSDrive C).Free
    Remove-Item -Path "$env:LOCALAPPDATA\Microsoft\DirectX Shader Cache\*" -Force -Recurse -ErrorAction SilentlyContinue
    $after = (Get-PSDrive C).Free
    Log-Message "DirectX Shader Cache cleaned." ($after - $before)
    Log-ExecutionTime "Clean-DXShaderCache" $startTime
}

# Function to empty recycle bin
function Empty-RecycleBin {
    $startTime = Get-Date
    Log-Message "Emptying Recycle Bin..."
    $before = (Get-PSDrive C).Free
    Clear-RecycleBin -Force -ErrorAction SilentlyContinue
    $after = (Get-PSDrive C).Free
    Log-Message "Recycle Bin emptied." ($after - $before)
    Log-ExecutionTime "Empty-RecycleBin" $startTime
}

# Function to clean Windows Update files manually
function Clean-WindowsUpdateFiles {
    $startTime = Get-Date
    Log-Message "Cleaning Windows Update files..."
    $before = (Get-PSDrive C).Free
    Remove-Item -Path "C:\Windows\SoftwareDistribution\Download\*" -Force -Recurse -ErrorAction SilentlyContinue
    $after = (Get-PSDrive C).Free
    Log-Message "Windows Update files cleaned." ($after - $before)
    Log-ExecutionTime "Clean-WindowsUpdateFiles" $startTime
}

# Main script execution
Log-Message "Starting system cleaning tasks..."
Log-Message "----------------------------"
Disk-SpaceAnalysis # Initial disk space analysis
Optimize-SSD
Clean-WindowsUpdateFiles
Clean-TempFiles
Clean-BrowserCache
Clean-ThumbnailCache
Clean-Prefetch
Clean-TempFonts
Flush-DNSCache
Clean-SystemTempFiles
Clean-PrinterTempFiles
Clean-DXShaderCache
Empty-RecycleBin
Disk-SpaceAnalysis # Final disk space analysis
Log-Message "System cleaning completed. Total space freed: $([math]::Round($global:totalSpaceFreed / 1MB, 2)) MB."
Log-Message "----------------------------"

# Prompt to keep the window open
Write-Host "Press any key to exit..."
[void][System.Console]::ReadKey($true)
